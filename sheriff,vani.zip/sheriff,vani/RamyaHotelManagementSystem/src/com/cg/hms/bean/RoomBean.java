package com.cg.hms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity

@Table(name="RoomDetails")
public class RoomBean {
	@Id
		@Column(name="room_id")
    private int room_id;
		@Column(name="hotel_id")
	private int hotel_id;
		@Column(name="room_no")
	private String room_no;
		@Column(name="room_type")
	private String room_type;
		@Column(name="per_night_rate")
	private int per_night_rate;
		@Column(name="availability")
	private boolean availability;
	
	/******************************************************************************************************************
	                                       Default constructor
	********************************************************************************************************************/
	public RoomBean() {
		// TODO Auto-generated constructor stub
	}
	
	/******************************************************************************************************************
                                          Getters&Setters
    ********************************************************************************************************************/
	
	
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getPer_night_rate() {
		return per_night_rate;
	}
	public void setPer_night_rate(int per_night_rate) {
		this.per_night_rate = per_night_rate;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
		
	public int getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}

	/******************************************************************************************************************
                                         Parameterized constructor
    ********************************************************************************************************************/
	
	public RoomBean(int room_id, int hotel_id, String room_no,
			String room_type, int per_night_rate, boolean availability) {
		super();
		this.room_id = room_id;
		this.hotel_id = hotel_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
	}

	
	/******************************************************************************************************************
                                            To String
   ********************************************************************************************************************/
	
	@Override
	public String toString() {
		return "RoomBean [room_id=" + room_id + ", hotel_id=" + hotel_id
				+ ", room_no=" + room_no + ", room_type=" + room_type
				+ ", per_night_rate=" + per_night_rate + ", availability="
				+ availability + "]";
	}
	
	
	
}
