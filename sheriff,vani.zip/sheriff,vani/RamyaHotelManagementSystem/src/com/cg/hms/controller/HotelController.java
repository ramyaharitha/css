package com.cg.hms.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hms.bean.AdminBean;
import com.cg.hms.bean.EmployeeBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
import com.cg.hms.service.IHotelService;




@Controller
public class HotelController {

	/*First Page*/
	@RequestMapping(value="home")
	public String getHome(Model m)
	{
		return "home";
	}


	////////////////////////////////////////////////////////////////////////////////////////

	@RequestMapping(value="user",method = RequestMethod.POST)								
	public String user(Model m,@ModelAttribute("userBean") UserBean userbean )
	{
		return "userlogin";
	}

	@RequestMapping(value="emp",method = RequestMethod.POST)
	public String emp(Model m)
	{
		return "employeelogin";
	}

	@RequestMapping(value="employeelogin")
	public String getEmpLoginPage(Model m)
	{
		return "employeelogin";
	}

	@RequestMapping(value="login")
	public String getadminloginPage(Model m)
	{
		return "login";
	}
	@RequestMapping("reg")
	public String getregistration(Model m)
	{
		m.addAttribute("regObj", new  UserBean());
		return "UserRegistration";
	}

	/*
	 * ****************************************Admin Functionality***************************************************** 
	 */	


	@RequestMapping(value="admin",method = RequestMethod.POST)
	public String main(Model m,@ModelAttribute("loginBean") HotelBean hotel)
	{
		return "adminlogin";
	}
	@RequestMapping(value="hotelmanagement")                                        //Hotel Management
	public String performHotelManagement(Model m)
	{
		return "adminhm";

	}
	@RequestMapping(value="roommanagement")                                        //Room Management
	public String performRoomManagement(Model m)
	{
		return "adminrm";

	}

	/****************************Generate Reports***************************************/

	@RequestMapping(value="report")
	public String generateReport(Model m)
	{
		return "adminreport";

	}

	/****************************Hotel Management***************************************/

	@RequestMapping(value="addhotel")                                                           // Add Hotel
	public String addHotel(Model m,@ModelAttribute("hotelObj") HotelBean hotel )
	{
		return "addhotel";

	}
	@RequestMapping(value="deletehotel")                                                          // Delete Hotel
	public String deleteHotel(Model m,@ModelAttribute("deletehotelObj") HotelBean hotel)
	{
		return "deletehotel";

	}
	@RequestMapping(value="updatehotel")                                                          //Update Hotel
	public String updateHotel(Model m)
	{
		return "updatehotel";

	}

	/****************************Room Management***************************************/

	@RequestMapping(value="addroom")															//Add Room
	public String addRoom(Model m,@ModelAttribute("roomObj") RoomBean room)
	{
		return "addroom";

	}
	@RequestMapping(value="deleteroom")															//Delete Room
	public String deleteRoom(Model m)
	{
		return "deleteroom";

	}
	@RequestMapping(value="updateroom")														//Update Room
	public String updateRoom(Model m)
	{
		return "updateroom";

	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	@Autowired
	private IHotelService hserv;

	////////////////////////User Register/////////////////////////////
	@RequestMapping(value="register",method=RequestMethod.POST)
	public  String storeRechargeInfo(Model m,@ModelAttribute("regObj") UserBean u){
		String target=null;

		int  userId=hserv.addUserDetails(u);
		if( userId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", userId);
			target="success";
		}
		else{
			target="UserRegistration";
		}
		return target;
	}
	////////////////////////User Login/////////////////////////////

	@RequestMapping(value="Userform",method = RequestMethod.POST)
	public String submit3(Model model, @ModelAttribute("userBean") UserBean userbean) {
		String target=null;
		model.addAttribute(userbean);
		model.addAttribute("user",userbean.getUserName());
		model.addAttribute("pass",userbean.getPassword());
		boolean val=hserv.login(userbean.getUserName(),userbean.getPassword(),userbean);
		if(val)
		{
			target="usermainscreen";
		}
		else
		{
			target="userlogin";
			model.addAttribute("status","Login Successfull");
		}
		return target;
				
		
	}
	////////////////////////Emplpoyee Login/////////////////////////////

	@RequestMapping(value="empForm",method = RequestMethod.POST)
	public String submit1(Model model, @ModelAttribute("empBean") EmployeeBean empBean)
	{
		if (empBean != null && empBean.getUserName() != null & empBean.getPassword() != null)
		{
			if (empBean.getUserName().equals("emp") && empBean.getPassword().equals("emp")) 
			{
				model.addAttribute("msg", empBean.getUserName());
				return "empmainscreen";
			} else {
				model.addAttribute("error", "Invalid Details");
				return "employeelogin";
			}
		} else {
			model.addAttribute("error", "Please enter Details");
			return "employeelogin";
		}
	}	


	////////////////////////Admin Register/////////////////////////////

	@RequestMapping(value="adminForm",method = RequestMethod.POST)
	public String submit(Model model, @ModelAttribute("loginBean") AdminBean loginBean) {
		if (loginBean != null && loginBean.getUserName() != null & loginBean.getPassword() != null) 
		{
			if (loginBean.getUserName().equals("admin") && loginBean.getPassword().equals("admin")) 
			{
				model.addAttribute("msg", loginBean.getUserName());
				return "adminmainscreen";
			}
			else 
			{
				model.addAttribute("error", "Invalid Details");
				return "adminlogin";
			}
		} 
		else 
		{
			model.addAttribute("error", "Please enter Details");
			return "adminlogin";
		}
	}
	////////////////////////Search Hotel/////////////////////////////
	@RequestMapping(value="searchhotel",method = RequestMethod.POST)
	public String search()
	{
		return null;

	}
	/************************************************************Hotel Management Methods**********************************************************/
	////////////////////////Add Hotel/////////////////////////////
	@RequestMapping(value="performaddhotel",method=RequestMethod.POST)
	public  String storehotel(Model m,@ModelAttribute("hotelObj") HotelBean hotelbean){
		String target=null;
		int  userId=hserv.addHotelServ(hotelbean);
		if( userId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", userId);
			target="success";
		}
		else{
			target="UserRegistration";
		}
		return target;
	}


	@RequestMapping(value="deletehotelbyid",method=RequestMethod.POST)
	public  String deletehotel(Model m,@ModelAttribute("deletehotelObj") HotelBean hotelbean)
	{
		String target=null;
		int deletehotelid = hotelbean.getHotel_id();
		int result;
		result=hserv.deleteHotelById(deletehotelid);
		if(result>0)
		{
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteid", deletehotelid);
			target="deletesuccess";
		}
		else
		{
			target="home";
		}
		return target;
	}
	/************************************************************Room Management Methods**********************************************************/
	////////////////////////Add Room/////////////////////////////

	@RequestMapping(value="performaddroom",method=RequestMethod.POST)
	public  String storeroom(Model m,@ModelAttribute("roomObj") RoomBean roombean){
		String target=null;
		int  roomId=hserv.addRoomServ(roombean);
		if( roomId>0){
			System.out.println("in if");
			m.addAttribute("msg","stored successfully");
			m.addAttribute("id", roomId);
			target="success";
		}
		else{
			target="UserRegistration";
		}
		return target;
	}
	/*******************************************************GENERATE VARIOUS REPORTS**************************************************************/
	/*******************************************************************************************************************************
	 *                                             VIEW LIST OF ALL HOTELS METHOD
	 * ******************************************************************************************************************************/


	@RequestMapping(value="viewall",method=RequestMethod.POST)
	public ModelAndView viewAll(){
		ModelAndView mv=new ModelAndView();
		ArrayList<HotelBean> hotellist=hserv.getAllHotels();
		mv.setViewName("viewallhotels");
		mv.addObject("data", hotellist);
		return mv;
	}



	/*********************************************************************************************************************************************
	 *                                                  VIEW BOOKINGS OF SPECIFIC HOTEL METHOD                                                     *
	 *********************************************************************************************************************************************/




	/*********************************************************************************************************************************************
	 *                                                  VIEW BOOKINGS OF SPECIFIC HOTEL METHOD                                                     *
	 *********************************************************************************************************************************************/







	/*********************************************************************************************************************************************
	 *                                                  VIEW BOOKINGS OF SPECIFIC HOTEL METHOD                                                     *
	 *********************************************************************************************************************************************/

}



